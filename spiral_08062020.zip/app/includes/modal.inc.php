<div class="modal">
  <div class="modal__content">
    <div class="modal__header">
      <h4>Spiral</h4>
      <div class="modal__close"><?php include("images/close.svg"); ?></div>
    </div>
    <div class="modal__body">
      <iframe width="100%" height="470" src="" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
  </div>
</div>