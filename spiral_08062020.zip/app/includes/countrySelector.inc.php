<div class="countrySelector">
  <i class="icon icon-globe"></i>
  <span></span>
  <ul class="list">
    <li><a href="#Brasil">Brasil</a></li>
    <li><a href="#Mexico ">México </a></li>
    <li><a href="#Chile">Chile</a></li>
    <li><a href="#Colombia">Colombia</a></li>
    <li><a href="#Uruguay">Uruguay</a></li>
  </ul>
</div>